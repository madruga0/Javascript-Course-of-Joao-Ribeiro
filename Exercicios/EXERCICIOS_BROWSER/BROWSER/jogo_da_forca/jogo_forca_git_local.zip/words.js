let words = [
    "aplicativo",
    "tecnologia",
    "computador",
    "programador",
    "javascript",
    "internet",
    "desenvolvimento",
    "software",
    "algoritmo",
    "interface",
    "sistema",
    "inovacao",
    "programacao",
    "dados",
    "criptografia",
    "inteligencia",
    "artificial",
    "redes",
    "seguranca",
];

export { words };